package com.yugabyte;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");
        Connection conn = DriverManager.getConnection(
                "jdbc:postgresql://127.0.1.1:5433/yugabyte",
                "yugabyte",
                "yugabyte");
        Statement stmt = conn.createStatement();
        try {
            System.out.println("Connected to the YugabyteDB Cluster successfully.");
            stmt.execute("DROP TABLE IF EXISTS Warehouse");
            stmt.execute("CREATE TABLE IF NOT EXISTS Warehouse (W_ID integer PRIMARY KEY,W_NAME varchar(10),W_STREET_1 varchar(20),W_STREET_2 varchar(20),W_CITY varchar(20),W_STATE char(2),W_ZIP char(9),W_TAX decimal(4,4),W_YTD decimal(12,2));");
            stmt.execute("COPY warehouse (W_ID, W_NAME, W_STREET_1, W_STREET_2, W_CITY, W_STATE, W_ZIP, W_TAX, W_YTD) " +
                    "FROM '/home/eric/Desktop/TestTransaction2/src/main/resources/warehouse.csv' " + //remember to change this dir
                    "WITH (delimiter',');");

            //testing if data loaded properly
            ResultSet rs = stmt.executeQuery("select w_id, w_name from warehouse");
            while (rs.next()) {
                System.out.printf("Query returned: w_id = %d, w_name = %s%n",
                        rs.getInt(1), rs.getString(2));
            }

            //dummy example can be deleted (good reference for some Java & SQL syntax)
            stmt.execute("DROP TABLE IF EXISTS employee");
            stmt.execute("CREATE TABLE IF NOT EXISTS employee" +
                    "  (id int primary key, name varchar, age int, language text)");
            System.out.println("Created table employee");

            String insertStr = "INSERT INTO employee VALUES (1, 'John', 35, 'Java')";
            stmt.execute(insertStr);
            System.out.println("EXEC: " + insertStr);

//            ResultSet rs = stmt.executeQuery("select * from employee");
//            while (rs.next()) {
//                System.out.printf("Query returned: name = %s, age = %s, language = %s%n",
//                        rs.getString(2), rs.getString(3), rs.getString(4));
//            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}